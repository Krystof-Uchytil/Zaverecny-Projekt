package com.example.projekt_rugbytrainings;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

public class TrainingPlanActivity extends AppCompatActivity {

    private TextView tvNearestTrainingSpot, tvTrainingPlanResult;
    private Button btnGeneratePlan;
    private DatabaseHelper dbHelper;
    private FusedLocationProviderClient fusedLocationClient;
    private String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_training_plan);

        // Inicializace UI prvků
        tvNearestTrainingSpot = findViewById(R.id.tv_nearest_training_spot);
        tvTrainingPlanResult = findViewById(R.id.tv_training_plan_result);
        btnGeneratePlan = findViewById(R.id.btn_generate_plan);

        // Inicializace databáze a GPS klienta
        dbHelper = new DatabaseHelper(this);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Načtení e-mailu uživatele ze SharedPreferences
        SharedPreferences prefs = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        userEmail = prefs.getString("USER_EMAIL", null);

        if (userEmail == null || userEmail.isEmpty()) {
            Toast.makeText(this, "❌ Chyba: E-mail uživatele není dostupný.", Toast.LENGTH_LONG).show();
            finish(); // Ukončí aktivitu, protože bez e-mailu nemůžeme pokračovat
            return;
        }

        // Akce pro tlačítko generování tréninkového plánu
        btnGeneratePlan.setOnClickListener(v -> generateTrainingPlan());
    }

    @SuppressLint("SetTextI18n")
    private void generateTrainingPlan() {
        // Ověření GPS oprávnění
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }

        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null) {
                // Najdeme nejbližší tréninkové místo
                String nearestSpot = findNearestTrainingSpot(location);
                tvNearestTrainingSpot.setText(getString(R.string.label_nearest_training_spot) + " " + nearestSpot);

                // Vygenerování tréninkového plánu
                String plan = generatePlan(nearestSpot);
                tvTrainingPlanResult.setText(plan);

                // Uložíme plán do databáze
                boolean success = dbHelper.saveTrainingPlan(userEmail, plan);
                if (success) {
                    Toast.makeText(this, "✅ Tréninkový plán úspěšně uložen!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "❌ Chyba při ukládání plánu.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, R.string.error_location, Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Simulovaná metoda pro nalezení nejbližšího tréninkového místa
    private String findNearestTrainingSpot(Location location) {
        // Tady by bylo reálné vyhledávání na základě databáze míst nebo jiných metod
        return "Městský stadion"; // Pevná hodnota pro testování
    }

    // Generování tréninkového plánu podle lokality
    private String generatePlan(String nearestSpot) {
        return "Váš tréninkový plán u místa: " + nearestSpot;
    }

    // Zpracování žádosti o GPS oprávnění
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                generateTrainingPlan();
            } else {
                Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_SHORT).show();
            }
        }
    }
}