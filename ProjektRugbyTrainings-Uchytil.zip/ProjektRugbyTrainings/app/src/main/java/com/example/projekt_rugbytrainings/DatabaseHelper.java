package com.example.projekt_rugbytrainings;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "rugby_training.db";
    private static final int DATABASE_VERSION = 1;

    // Tabulka uživatelů
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_HEIGHT = "height";
    private static final String COLUMN_WEIGHT = "weight";
    private static final String COLUMN_POSITION = "position";
    private static final String COLUMN_FREQUENCY = "training_frequency";
    private static final String COLUMN_LEVEL = "league_level";

    // Tabulka statistik
    private static final String TABLE_STATISTICS = "statistics";
    private static final String COLUMN_STATS_ID = "id";
    private static final String COLUMN_USER_EMAIL = "user_email";
    private static final String COLUMN_TRAINING_COUNT = "training_count";
    private static final String COLUMN_TOTAL_HOURS = "total_hours";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Tabulka uživatelů
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_EMAIL + " TEXT UNIQUE, " +
                COLUMN_PASSWORD + " TEXT, " +
                COLUMN_HEIGHT + " REAL, " +
                COLUMN_WEIGHT + " REAL, " +
                COLUMN_POSITION + " TEXT, " +
                COLUMN_FREQUENCY + " INTEGER, " +
                COLUMN_LEVEL + " TEXT)";
        db.execSQL(CREATE_USERS_TABLE);

        // Tabulka statistik
        String CREATE_STATISTICS_TABLE = "CREATE TABLE " + TABLE_STATISTICS + " (" +
                COLUMN_STATS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USER_EMAIL + " TEXT, " +
                COLUMN_TRAINING_COUNT + " INTEGER, " +
                COLUMN_TOTAL_HOURS + " REAL, " +
                "FOREIGN KEY(" + COLUMN_USER_EMAIL + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_EMAIL + "))";
        db.execSQL(CREATE_STATISTICS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STATISTICS);
        onCreate(db);
    }
    public boolean registerUser(String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("email", email);
        values.put("password", password);

        long result = db.insert("users", null, values);
        db.close();
        return result != -1;
    }

    // 📌 Přidání nového uživatele
    public boolean addUser(String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }
    public boolean saveTrainingPlan(String email, String plan) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("user_email", email);
        values.put("training_plan", plan);

        long result = db.insert("training_plans", null, values);
        db.close();
        return result != -1; // Vrátí true, pokud bylo uložení úspěšné
    }
    // 📌 Kontrola přihlášení
    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE email=? AND password=?", new String[]{email, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // 📌 Načtení profilu uživatele
    public Cursor getUserProfile(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT height, weight, position, training_frequency, league_level FROM " + TABLE_USERS + " WHERE email=?", new String[]{email});
    }

    // 📌 Aktualizace profilu uživatele
    public boolean updateUserProfile(String email, double height, double weight, String position, int frequency, String level) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_HEIGHT, height);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_POSITION, position);
        values.put(COLUMN_FREQUENCY, frequency);
        values.put(COLUMN_LEVEL, level);

        int rowsUpdated = db.update(TABLE_USERS, values, COLUMN_EMAIL + "=?", new String[]{email});
        return rowsUpdated > 0;
    }

    // 📌 Načtení statistik uživatele
    public Cursor getStatistics(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT training_count, total_hours FROM " + TABLE_STATISTICS + " WHERE user_email=?", new String[]{email});
    }

    // 📌 Aktualizace statistik uživatele
    public boolean updateStatistics(String email, double totalScore, double avgScore, int matches) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("total_score", totalScore);
        values.put("avg_score", avgScore);
        values.put("matches_played", matches);

        int rows = db.update("statistics", values, "user_email = ?", new String[]{email});
        db.close();
        return rows > 0;
    }



    // 📌 Vložení statistik uživatele (pokud neexistují)
    public boolean insertStatistics(String email, int trainingCount, double totalHours) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_EMAIL, email);
        values.put(COLUMN_TRAINING_COUNT, trainingCount);
        values.put(COLUMN_TOTAL_HOURS, totalHours);

        long result = db.insert(TABLE_STATISTICS, null, values);
        return result != -1;
    }


    // 📌 Kontrola, zda uživatel má statistiky
    public boolean hasStatistics(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_STATISTICS + " WHERE user_email=?", new String[]{email});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }
}